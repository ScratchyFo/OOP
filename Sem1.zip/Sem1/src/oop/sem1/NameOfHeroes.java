package OOP.sem1;

public enum NameOfHeroes {
    Дмитрий, Александр, Вячеслав, Иван, Роман;
}